from spicy_vki.spicy import Spicy

from spicy_vki.utils._basis_collocation import *
from spicy_vki.utils._basis_Harmonic import *
from spicy_vki.utils._basis_RBF import *
from spicy_vki.utils._extnumpy import *
from spicy_vki.utils._input_checks import *